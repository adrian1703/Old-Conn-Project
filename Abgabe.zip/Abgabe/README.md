# Programmieraufgabe

Alle Programme sind kompiliert in den dazugehörigen jar Datei und 
können damit ausgeführt werden. 

Bei Aufgabe 1 sollte beachtet werden, dass der Server auf das
Verzeichnis zugreift, in dem er ausgeführt wird. Die Test Dateien
müssen sich demnach auch in dem Verzeichnis befinden.

