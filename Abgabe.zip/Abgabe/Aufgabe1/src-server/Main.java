public class Main {

    public static void main(String[] args)
    {
        Server server = new Server(2000);
        server.run();
    }
}
